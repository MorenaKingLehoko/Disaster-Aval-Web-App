using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Aval.Pages.Disasters
{
    public class AdminHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
