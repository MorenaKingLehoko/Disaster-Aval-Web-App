using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Aval.Pages.Load_Donations
{
    public class ActiveDisastersModel : PageModel
    {
        public string DisasterDiscription { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; }
        public string AidRequired { get; set; }
        public void OnGet()
        {
        }
    }
}
