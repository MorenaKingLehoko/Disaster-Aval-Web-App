using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Aval.Pages.Donation
{
    public class GoodsDonationsModel : PageModel
    {
        [DisplayName("Today's Date")]
        [Required]
        public DateTime DonationDate { get; set; }


        [DisplayName("How Many Items Are you Donating")]
        [Required]
        public int NumberOfItems { get; set; }


        [DisplayName("Category, eg Shelter, building material")]
        [Required]
        public string Category { get; set; }


        [DisplayName("Brief Description")]
        public string Desription { get; set; }
       
        
        public void OnGet()
        {
        }
    }
}
