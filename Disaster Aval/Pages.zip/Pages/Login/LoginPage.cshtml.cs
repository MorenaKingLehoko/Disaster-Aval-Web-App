using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Aval.Pages.Login
{
    public class LoginPageModel : PageModel
    {
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            LoginViewModel loginViewModel = new LoginViewModel(); // a new instance of LoginViewModel

            //getting data from the form

            //converting to int
            loginViewModel.ID = int.Parse(Request.Form["ID"]);

            loginViewModel.Name = Request.Form["Name"];
            loginViewModel.Surname = Request.Form["Surname"];
            loginViewModel.Password = Request.Form["Password"];

            //database function here

            //Insert into <Table> what i get from the form
            if (loginViewModel.ID== 1 && loginViewModel.Name == "Morena" && loginViewModel.Surname == "Lehoko" && loginViewModel.Password == "1234")
            {



                // Returning the LoginSuccess page if the login was successful and passing in the model to display the details
                return RedirectToPage("LoginSucces", loginViewModel);
            }
            else
            {
                // If the login was not successful, you might want to return an error view or redirect to a different page.
                return RedirectToPage("LoginFailed", loginViewModel);
            }
        }
    }
}
