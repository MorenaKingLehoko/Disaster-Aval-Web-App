using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Aval.Pages.Login
{
    public class AdminLoginModel : PageModel
    {
        [DisplayName("Your Admin ID:")]
        [Required]
        public int AdminId { get; set; }


        [DisplayName("Password")]
        [Required]
        public string AdminPassword { get; set; }


        [DisplayName("Email")]
        public string AdminEmail { get; set; }
        
        

        //public void OnGet()
        //{
        //}
        public IActionResult OnPost()
        {
            AdminLoginModel loginViewModel = new AdminLoginModel(); // a new instance of LoginViewModel

            //getting data from the form

            //converting to int

            loginViewModel.AdminId = int.Parse(Request.Form["AdminId"]);
            loginViewModel.AdminEmail = Request.Form["AdminEmail"];
            loginViewModel.AdminPassword =  Request.Form["AdminPassword"];

            //database function here

            //Insert into <Table> what i get from the form
            if (loginViewModel.AdminId == 1 && loginViewModel.AdminEmail == "email.com" && loginViewModel.AdminPassword == "1234")
            {



                // Returning the LoginSuccess page if the login was successful and passing in the model to display the details
                return RedirectToPage("/Disasters/AdminHome", loginViewModel);
            }
            else
            {
                // If the login was not successful, you might want to return an error view or redirect to a different page.
                return RedirectToPage("LoginFailed", loginViewModel);
            }
        }
    }
}

